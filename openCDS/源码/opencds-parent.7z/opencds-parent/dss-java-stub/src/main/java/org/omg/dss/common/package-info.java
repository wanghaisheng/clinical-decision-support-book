@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.omg.org/spec/CDSS/201105/dss")
package org.omg.dss.common;
