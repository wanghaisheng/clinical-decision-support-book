package org.opencds.common.exceptions;

public class OpenCDSCoreError extends Exception {

	private static final long serialVersionUID = 8320316913468643769L;

	public OpenCDSCoreError(String message) {
		super(message);
	}
}
