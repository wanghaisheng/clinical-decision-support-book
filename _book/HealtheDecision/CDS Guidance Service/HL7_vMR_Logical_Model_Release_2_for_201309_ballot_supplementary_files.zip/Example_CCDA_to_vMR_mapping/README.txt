The CDA and vMR XML Schemas are provided SOLELY for the purpose of allowing the sample XML files to be schema validated.  They carry no other significance in this specification.

The CDA schema was obtained from the HL7 Version 3 Normative Edition, 2012.

The vMR schema was obtained from the HL7 vMR-CDS XML Implementation Guide Release 1 as of August 29, 2013.