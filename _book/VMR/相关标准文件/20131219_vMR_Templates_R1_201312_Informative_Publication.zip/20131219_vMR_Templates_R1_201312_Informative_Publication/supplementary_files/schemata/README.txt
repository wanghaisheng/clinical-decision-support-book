The vMR XML Schemas are provided SOLELY for the purpose of allowing the sample XML files to be schema validated.  They carry no other significance in this specification.

The vMR schema was obtained from the HL7 vMR-CDS XML Specification Release 1 as of December 16, 2013.